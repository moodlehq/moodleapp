# Odoo API Specification for Parent Manager Plugin

> **Critical**: This document specifies the exact API endpoint that the Odoo team must implement for the Moodle Parent Manager plugin to work.

## 🎯 Required Endpoint

### GET `/api/student/{sequence}/parents`

Returns parent/guardian information for a given student sequence number.

**Purpose**: Enable Moodle to automatically create parent accounts and link them to students.

---

## Request

**URL Pattern**:
```
https://aspire-school.odoo.com/api/student/{sequence}/parents
```

**Method**: `GET`

**Authentication**: None (public endpoint) or configure as needed

**Parameters**:
- `{sequence}` - Student sequence/ID number from Odoo (e.g., "STU001", "1234", "2024001")

**Headers**:
```http
Accept: application/json
Content-Type: application/json
```

**Example Requests**:
```bash
# With text sequence
curl "https://aspire-school.odoo.com/api/student/STU001/parents"

# With numeric sequence
curl "https://aspire-school.odoo.com/api/student/1234/parents"

# With year-based sequence
curl "https://aspire-school.odoo.com/api/student/2024001/parents"
```

---

## Response Format

### Success Response

**HTTP Status**: `200 OK`

```json
{
  "success": true,
  "student": {
    "sequence": "STU001",
    "name": "Ahmed Ali Hassan"
  },
  "parents": [
    {
      "type": "father",
      "sequence": "PAR001",
      "name": "Ali Hassan",
      "first_name": "Ali",
      "last_name": "Hassan",
      "email": "ali.hassan@example.com",
      "mobile": "+971501234567",
      "phone": "+97142345678",
      "is_academic_contact": true,
      "is_financial_contact": true
    },
    {
      "type": "mother",
      "sequence": "PAR002",
      "name": "Fatima Ahmed",
      "first_name": "Fatima",
      "last_name": "Ahmed",
      "email": "fatima.ahmed@example.com",
      "mobile": "+971509876543",
      "phone": "",
      "is_academic_contact": false,
      "is_financial_contact": true
    }
  ]
}
```

### Error Response

**HTTP Status**: `200 OK` (with `success: false`)

```json
{
  "success": false,
  "error": "Student not found"
}
```

---

## Field Specifications

### Parent Object Fields

| Field | Type | Required | Description | Example | Notes |
|-------|------|----------|-------------|---------|-------|
| `first_name` | string | **✅ REQUIRED** | Parent's first name | `"Ali"` | Cannot be empty |
| `last_name` | string | **✅ REQUIRED** | Parent's last name/surname | `"Hassan"` | Cannot be empty |
| `email` | string | **✅ REQUIRED** | Email address | `"ali@email.com"` | **Must be unique across ALL parents** |
| `type` | string | ⚠️ Optional | Relationship type | `"father"`, `"mother"`, `"guardian"` | For display purposes |
| `sequence` | string | ⚠️ Optional | Parent ID/sequence in Odoo | `"PAR001"` | **Recommended** - Used in financial dashboard |
| `name` | string | ⚠️ Optional | Full name | `"Ali Hassan"` | Not used by plugin |
| `mobile` | string | ⚠️ Optional | Mobile phone number | `"+971501234567"` | International format preferred |
| `phone` | string | ⚠️ Optional | Landline/home phone | `"+97142345678"` | International format preferred |
| `is_academic_contact` | boolean | ⚠️ Optional | Academic matters contact | `true`, `false` | For future use |
| `is_financial_contact` | boolean | ⚠️ Optional | Financial matters contact | `true`, `false` | For future use |

### Student Object Fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `sequence` | string | ✅ Yes | Student sequence number (echoed back) |
| `name` | string | ⚠️ Optional | Student full name |

---

## Important Notes

### 🔴 Email Uniqueness (CRITICAL!)

⚠️ **CRITICAL REQUIREMENT**: Each parent's email address must be **globally unique** across your entire parent database.

**How it works**:
- Email is the **primary identifier** for parent accounts in Moodle
- If the same parent has multiple children (siblings), use the **exact same email** in all responses
- Moodle will automatically handle the linking

**What happens**:
1. **First student sync**: Moodle creates parent account with email `ali@example.com`
2. **Second student sync (sibling)**: Moodle sees email `ali@example.com` exists, updates the account and links to second student
3. Result: One parent account linked to both students ✅

**Example for siblings**:

```bash
# Student 1
GET /api/student/STU001/parents
{
  "parents": [{
    "email": "ali.hassan@example.com",
    "first_name": "Ali",
    "last_name": "Hassan"
  }]
}

# Student 2 (sibling)
GET /api/student/STU002/parents
{
  "parents": [{
    "email": "ali.hassan@example.com",  # Same email!
    "first_name": "Ali",
    "last_name": "Hassan"
  }]
}
```

Result: One parent account linked to both students. ✅

### Empty Parents Array

If a student has no parents or guardians, return an empty array:

```json
{
  "success": true,
  "student": {
    "sequence": "STU001",
    "name": "Ahmed Ali"
  },
  "parents": []
}
```

The plugin will skip this student without errors.

### Multiple Parents

You can return **0 to 10 parents** per student. Common scenarios:

- **0 parents**: Student has no registered guardians (plugin will skip gracefully)
- **1 parent**: Single parent household
- **2 parents**: Father + Mother (most common)
- **3+ parents**: Father + Mother + Guardian(s) (stepparents, legal guardians, etc.)

**Note**: All parents in the array will be linked to the student with equal access rights.

---

## Testing Your Implementation

### ✅ Pre-Deployment Checklist

Before going live, verify:

1. **✅ Endpoint is accessible**: Moodle server can reach `https://aspire-school.odoo.com`
2. **✅ Response is valid JSON**: All responses return properly formatted JSON
3. **✅ Required fields present**: Every parent has `first_name`, `last_name`, and `email`
4. **✅ Email uniqueness**: Same parent = same email for all their children
5. **✅ Student not found**: Returns `{"success": false, "error": "Student not found"}`
6. **✅ No parents**: Returns `{"success": true, "parents": []}`

### 1. Test with curl

```bash
curl -X GET "https://aspire-school.odoo.com/api/student/TEST001/parents" \
  -H "Accept: application/json"
```

### 2. Validate JSON Response

Check that you get valid JSON with required fields:

```bash
# Should output: Ali Hassan
curl -s "https://aspire-school.odoo.com/api/student/TEST001/parents" | \
  jq -r '.parents[0].first_name + " " + .parents[0].last_name'

# Validate JSON structure
curl -s "https://aspire-school.odoo.com/api/student/TEST001/parents" | \
  jq '.success, .parents | length'
```

### 3. Test from Moodle Server

**IMPORTANT**: Test from your actual Moodle server, not your local machine:

```bash
# SSH into Moodle server
ssh moodle-server

# Test connectivity
curl "https://aspire-school.odoo.com/api/student/STU001/parents"
```

Common issues:
- ❌ Firewall blocking Moodle → Odoo communication
- ❌ DNS not resolving aspire-school.odoo.com from Moodle server
- ❌ SSL certificate issues

### 4. Test Edge Cases

```bash
# Student with no parents
curl "https://aspire-school.odoo.com/api/student/ORPHAN001/parents"
# Expected: {"success": true, "parents": []}

# Non-existent student
curl "https://aspire-school.odoo.com/api/student/NOTFOUND/parents"
# Expected: {"success": false, "error": "Student not found"}

# Student with multiple siblings (same parents)
curl "https://aspire-school.odoo.com/api/student/SIB001/parents"
curl "https://aspire-school.odoo.com/api/student/SIB002/parents"
# Expected: Same email addresses in both responses
```

---

## Sample Odoo Controller Implementation

```python
from odoo import http
from odoo.http import request
import json

class StudentParentAPI(http.Controller):

    @http.route('/api/student/<string:sequence>/parents',
                type='http', auth='public', methods=['GET'],
                csrf=False, cors='*')
    def get_student_parents(self, sequence, **kwargs):
        """Get parent information for a student"""

        # Set JSON response headers
        headers = {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        }

        try:
            # Find student by sequence number
            # Adjust the model and field names to match your Odoo setup
            student = request.env['student.student'].sudo().search([
                ('sequence_number', '=', sequence)
            ], limit=1)

            if not student:
                return http.Response(
                    json.dumps({
                        'success': False,
                        'error': 'Student not found'
                    }),
                    headers=headers
                )

            parents = []

            # Father
            if student.father_id:
                parents.append({
                    'type': 'father',
                    'sequence': student.father_id.sequence_number or '',
                    'name': student.father_id.name,
                    'first_name': student.father_id.first_name or student.father_id.name.split()[0],
                    'last_name': student.father_id.last_name or ' '.join(student.father_id.name.split()[1:]),
                    'email': student.father_id.email or '',
                    'mobile': student.father_id.mobile or '',
                    'phone': student.father_id.phone or '',
                    'is_academic_contact': student.father_id.is_academic_contact or False,
                    'is_financial_contact': student.father_id.is_financial_contact or False,
                })

            # Mother
            if student.mother_id:
                parents.append({
                    'type': 'mother',
                    'sequence': student.mother_id.sequence_number or '',
                    'name': student.mother_id.name,
                    'first_name': student.mother_id.first_name or student.mother_id.name.split()[0],
                    'last_name': student.mother_id.last_name or ' '.join(student.mother_id.name.split()[1:]),
                    'email': student.mother_id.email or '',
                    'mobile': student.mother_id.mobile or '',
                    'phone': student.mother_id.phone or '',
                    'is_academic_contact': student.mother_id.is_academic_contact or False,
                    'is_financial_contact': student.mother_id.is_financial_contact or False,
                })

            # Guardians (if applicable)
            for guardian in student.guardian_ids:
                parents.append({
                    'type': 'guardian',
                    'sequence': guardian.sequence_number or '',
                    'name': guardian.name,
                    'first_name': guardian.first_name or guardian.name.split()[0],
                    'last_name': guardian.last_name or ' '.join(guardian.name.split()[1:]),
                    'email': guardian.email or '',
                    'mobile': guardian.mobile or '',
                    'phone': guardian.phone or '',
                    'is_academic_contact': guardian.is_academic_contact or False,
                    'is_financial_contact': guardian.is_financial_contact or False,
                })

            response_data = {
                'success': True,
                'student': {
                    'sequence': student.sequence_number,
                    'name': student.name
                },
                'parents': parents
            }

            return http.Response(
                json.dumps(response_data),
                headers=headers
            )

        except Exception as e:
            return http.Response(
                json.dumps({
                    'success': False,
                    'error': str(e)
                }),
                headers=headers
            )
```

---

## Quick Reference

### Valid Response Examples

**✅ Student with 2 parents:**
```json
{
  "success": true,
  "student": {"sequence": "STU001", "name": "Ahmed Ali"},
  "parents": [
    {"first_name": "Ali", "last_name": "Hassan", "email": "ali@example.com", "sequence": "PAR001"},
    {"first_name": "Fatima", "last_name": "Ahmed", "email": "fatima@example.com", "sequence": "PAR002"}
  ]
}
```

**✅ Student with no parents:**
```json
{
  "success": true,
  "student": {"sequence": "STU002", "name": "Omar Mohammed"},
  "parents": []
}
```

**✅ Student not found:**
```json
{
  "success": false,
  "error": "Student not found"
}
```

### Common Mistakes to Avoid

❌ **Different emails for same parent:**
```json
// WRONG - Father has different emails for two children
Student 1: {"email": "ali.hassan@email.com"}
Student 2: {"email": "ali_hassan@email.com"}  // Creates duplicate account!
```

✅ **Correct - Same email:**
```json
// CORRECT - Same email creates one account linked to both
Student 1: {"email": "ali.hassan@email.com"}
Student 2: {"email": "ali.hassan@email.com"}  // Updates existing account
```

❌ **Missing required fields:**
```json
// WRONG - Missing email
{"first_name": "Ali", "last_name": "Hassan"}
```

✅ **Correct - All required fields:**
```json
{"first_name": "Ali", "last_name": "Hassan", "email": "ali@example.com"}
```

---

## Questions?

If you need help implementing this endpoint, please provide:

1. Sample student record from your Odoo
2. Sample parent/guardian record structure
3. Field names you use for:
   - Student sequence/ID
   - Father relationship
   - Mother relationship
   - Guardian relationships
   - Parent email/phone fields

**Contact**: Provide API_SPEC.md to your Odoo development team
