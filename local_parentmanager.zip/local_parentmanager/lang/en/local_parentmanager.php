<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

/**
 * English language strings for local_parentmanager
 *
 * @package    local_parentmanager
 * @copyright  2025 Aspire School
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['pluginname'] = 'Parent Manager';
$string['privacy:metadata'] = 'The Parent Manager plugin does not store any personal data itself. It creates user accounts which are managed by Moodle core.';

// Capabilities
$string['parentmanager:manageparents'] = 'Manage parent accounts and synchronization';

// Tasks
$string['syncparentstask'] = 'Sync parents from Odoo API';

// Settings
$string['apiurl'] = 'Odoo API URL';
$string['apiurl_desc'] = 'Base URL for Odoo API (e.g., https://aspire-school.odoo.com)';
$string['apitimeout'] = 'API Timeout';
$string['apitimeout_desc'] = 'Timeout in seconds for API requests (default: 30)';
$string['studentrole'] = 'Student Role Shortname';
$string['studentrole_desc'] = 'The shortname of the student role (default: student)';
$string['parentrole'] = 'Parent Role Shortname';
$string['parentrole_desc'] = 'The shortname of the parent role (default: parent)';
$string['sequencefield'] = 'Sequence Field Shortname';
$string['sequencefield_desc'] = 'The shortname of the user profile field that stores student sequence numbers (default: ID)';
$string['sendemails'] = 'Send Email Notifications';
$string['sendemails_desc'] = 'Send login credentials to newly created parent accounts';
$string['enableautosync'] = 'Enable Automatic Sync';
$string['enableautosync_desc'] = 'Enable the scheduled task to automatically sync parents daily';
$string['debugmode'] = 'Debug Mode';
$string['debugmode_desc'] = 'Enable detailed logging for troubleshooting';

// Management page
$string['manageparents'] = 'Manage Parents';
$string['overview'] = 'Overview';
$string['parentlinks'] = 'Parent Links';
$string['students'] = 'Students';
$string['testapi'] = 'Test API';
$string['totalstudents'] = 'Students with Sequence';
$string['totalparents'] = 'Parent Accounts';
$string['totallinks'] = 'Parent-Student Links';
$string['studentsnoparents'] = 'Students Without Parents';
$string['pluginstatus'] = 'Plugin Status';
$string['parentrolefound'] = 'Parent role found: {$a}';
$string['sequencefieldfound'] = 'Sequence field found: {$a}';
$string['sequencefieldnotfound'] = 'Sequence field not found! Please create a custom user profile field.';
$string['apiurlconfigured'] = 'API URL: {$a}';
$string['quickactions'] = 'Quick Actions';
$string['viewscheduledtasks'] = 'View Scheduled Tasks';
$string['pluginsettings'] = 'Plugin Settings';
$string['parent'] = 'Parent';
$string['student'] = 'Student';
$string['linkedon'] = 'Linked On';
$string['sequence'] = 'Sequence';
$string['parentcount'] = 'Parents';
$string['syncnow'] = 'Sync Now';
$string['testapidescription'] = 'Test the Odoo API connection by entering a student sequence number:';
$string['studentsequence'] = 'Student Sequence';
$string['apiresponse'] = 'API Response';
$string['requestingurl'] = 'Requesting: {$a}';
$string['parentsfound'] = '{$a} parent(s) found in response';
$string['apidocumentation'] = 'API Documentation';
$string['apidocumentation_desc'] = 'The Odoo team needs to implement the API endpoint as specified in the documentation.';
$string['viewapidocs'] = 'View full API specification: {$a}';
$string['syncsuccessful'] = 'Sync successful! Created: {$a->parents_created}, Updated: {$a->parents_updated}, Linked: {$a->parents_linked}';
$string['syncfailed'] = 'Sync failed. Check the API configuration and try again.';
$string['apitestsuccess'] = 'API test successful! The endpoint is working correctly.';
$string['apitestfailed'] = 'API test failed. Please check the API configuration and endpoint implementation.';

// Errors
$string['nostudentsequence'] = 'Student does not have a sequence number in custom field ID';
$string['parentrolenotfound'] = 'Parent role not found. Please create a role with shortname "parent" at Site Administration > Users > Permissions > Define roles';

// Email templates
$string['parentcredentialssubject'] = '{$a} - Your Parent Account';
$string['parentcredentialsmessage'] = 'Dear {$a->firstname},

A parent account has been created for you at {$a->sitename}.

Your login credentials are:
Username: {$a->username}
Password: {$a->password}

You can log in at: {$a->loginurl}

Or download our mobile app: {$a->mobileappurl}

After logging in, you will be able to view your child\'s:
- Courses and assignments
- Grades and progress
- Teacher messages
- Financial information

If you have any questions, please contact the school.

Best regards,
{$a->sitename}';

$string['parentcredentialsmessagehtml'] = '<p>Dear {$a->firstname},</p>

<p>A parent account has been created for you at <strong>{$a->sitename}</strong>.</p>

<h3>Your Login Credentials</h3>
<ul>
<li><strong>Username:</strong> {$a->username}</li>
<li><strong>Password:</strong> {$a->password}</li>
</ul>

<p><a href="{$a->loginurl}">Click here to log in</a></p>

<p>Or download our mobile app: <a href="{$a->mobileappurl}">Aspire School App</a></p>

<h3>What You Can Do</h3>
<p>After logging in, you will be able to view your child\'s:</p>
<ul>
<li>Courses and assignments</li>
<li>Grades and progress</li>
<li>Teacher messages</li>
<li>Financial information</li>
</ul>

<p>If you have any questions, please contact the school.</p>

<p>Best regards,<br>{$a->sitename}</p>';
