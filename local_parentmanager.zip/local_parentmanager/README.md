# Parent Manager Plugin for Moodle

Automatically creates and links parent accounts by fetching data from Odoo API based on student sequence numbers.

## How It Works

1. **Daily Scheduled Task** runs at 2 AM
2. Finds all students with sequence numbers (custom field `ID`)
3. For each student, calls Odoo API: `https://aspire-school.odoo.com/api/student/{sequence}/parents`
4. Creates/updates parent accounts from API response
5. Links parents to students using Moodle's "parent" role
6. Sends login credentials to new parents via email

## Installation

```bash
# Copy to Moodle
cp -r local_parentmanager /var/www/html/moodle/local/

# Install via Moodle UI
# Go to: Site Administration > Notifications
```

After installation, you'll find:
- **Management Interface**: Site Administration > Plugins > Local plugins > Manage Parents
- **Plugin Settings**: Site Administration > Plugins > Local plugins > Parent Manager
- **Scheduled Task**: Site Administration > Server > Scheduled tasks > Sync parents from Odoo API

## Prerequisites

### 1. Parent Role Must Exist

Create a role with shortname `parent`:

1. Go to: **Site Administration > Users > Permissions > Define roles**
2. Click **Add a new role**
3. Use "Parent" archetype
4. **Critical**: Set **Short name** to `parent` (exactly)
5. Save

### 2. Student Sequence Custom Field

Students must have a custom profile field called `ID`:

1. Go to: **Site Administration > Users > User profile fields**
2. Create a text field:
   - **Short name**: `ID` (exactly)
   - **Name**: Sequence Number
   - **Category**: Student Information
3. Populate this field with Odoo sequence numbers for all students

---

## 🔗 API REQUIREMENTS

> **📄 Full API Specification**: See [API_SPEC.md](API_SPEC.md) for complete details to share with your Odoo team.

You need to create this endpoint in your Odoo system:

### Endpoint: Get Student Parents

**URL**: `https://aspire-school.odoo.com/api/student/{sequence}/parents`

**Method**: GET

**Path Parameter**:
- `{sequence}` - Student sequence number (e.g., "STU001", "1234")

**⚠️ CRITICAL**: Parent email addresses must be globally unique. Same parent = same email for all their children.

**Response Format**:

```json
{
  "success": true,
  "student": {
    "sequence": "STU001",
    "name": "Ahmed Ali Hassan"
  },
  "parents": [
    {
      "type": "father",
      "sequence": "PAR001",
      "name": "Ali Hassan",
      "first_name": "Ali",
      "last_name": "Hassan",
      "email": "ali.hassan@example.com",
      "mobile": "+971501234567",
      "phone": "+97142345678",
      "is_academic_contact": true,
      "is_financial_contact": true
    },
    {
      "type": "mother",
      "sequence": "PAR002",
      "name": "Fatima Ahmed",
      "first_name": "Fatima",
      "last_name": "Ahmed",
      "email": "fatima.ahmed@example.com",
      "mobile": "+971509876543",
      "phone": "",
      "is_academic_contact": false,
      "is_financial_contact": true
    }
  ]
}
```

### Required Fields in Response

**For each parent:**
- ✅ `first_name` (required) - Parent's first name
- ✅ `last_name` (required) - Parent's last name
- ✅ `email` (required, must be unique) - Email address
- ⚠️ `mobile` (optional) - Mobile phone number
- ⚠️ `phone` (optional) - Landline phone number
- ⚠️ `sequence` (optional but recommended) - Parent ID for tracking
- ⚠️ `type` (optional) - "father" or "mother"

### Error Response

```json
{
  "success": false,
  "error": "Student not found"
}
```

### Example Odoo Implementation Hints

In your Odoo controller, you might have something like:

```python
@http.route('/api/student/<string:sequence>/parents', type='json', auth='public', methods=['GET'], csrf=False)
def get_student_parents(self, sequence):
    # Find student by sequence
    student = request.env['student.student'].sudo().search([
        ('sequence_number', '=', sequence)
    ], limit=1)

    if not student:
        return {'success': False, 'error': 'Student not found'}

    parents = []

    # Father
    if student.father_id:
        parents.append({
            'type': 'father',
            'sequence': student.father_id.sequence_number or '',
            'name': student.father_id.name,
            'first_name': student.father_id.first_name,
            'last_name': student.father_id.last_name,
            'email': student.father_id.email,
            'mobile': student.father_id.mobile or '',
            'phone': student.father_id.phone or '',
            'is_academic_contact': student.father_id.is_academic_contact,
            'is_financial_contact': student.father_id.is_financial_contact,
        })

    # Mother
    if student.mother_id:
        parents.append({
            'type': 'mother',
            'sequence': student.mother_id.sequence_number or '',
            'name': student.mother_id.name,
            'first_name': student.mother_id.first_name,
            'last_name': student.mother_id.last_name,
            'email': student.mother_id.email,
            'mobile': student.mother_id.mobile or '',
            'phone': student.mother_id.phone or '',
            'is_academic_contact': student.mother_id.is_academic_contact,
            'is_financial_contact': student.mother_id.is_financial_contact,
        })

    return {
        'success': True,
        'student': {
            'sequence': student.sequence_number,
            'name': student.name
        },
        'parents': parents
    }
```

---

## 🎛️ Management Interface

Access the management interface at: **Site Administration > Plugins > Local plugins > Manage Parents**

### Features

**Overview Tab**
- 📊 Statistics dashboard (total students, parents, links)
- 🔍 Plugin status checks (role, fields, API)
- 🚀 Quick actions (view tasks, settings, test API)

**Parent Links Tab**
- View all parent-student relationships
- See when links were created
- Direct links to user profiles

**Students Tab**
- Search and filter students
- View parent count for each student
- **Sync Now** button for individual students
- Shows students missing parents

**Test API Tab**
- Test Odoo API connection
- Enter student sequence to verify response
- View raw JSON response
- Validate API implementation

### Plugin Settings

Configure via: **Site Administration > Plugins > Local plugins > Parent Manager**

- **API URL**: Odoo base URL (default: https://aspire-school.odoo.com)
- **API Timeout**: Request timeout in seconds (default: 30)
- **Student Role**: Role shortname for students (default: student)
- **Parent Role**: Role shortname for parents (default: parent)
- **Sequence Field**: Custom field shortname (default: ID)
- **Send Emails**: Enable/disable credential emails (default: enabled)
- **Auto Sync**: Enable/disable scheduled task (default: enabled)
- **Debug Mode**: Enable detailed logging (default: disabled)

---

## Usage

### Automatic Sync (Daily at 2 AM)

The plugin runs automatically every day at 2 AM. To change the schedule:

1. Go to: **Site Administration > Server > Scheduled tasks**
2. Find **Sync parents from Odoo API**
3. Click **Edit**
4. Set your preferred schedule

### Manual Sync via CLI

Sync a specific student:

```bash
# By student ID
cd /var/www/html/moodle
php local/parentmanager/cli/sync_parents.php --studentid=123

# By sequence number
php local/parentmanager/cli/sync_parents.php --sequence=STU001
```

Run full sync manually:

```bash
php admin/cli/scheduled_task.php --execute=\\local_parentmanager\\task\\sync_parents
```

### Manual Sync via Web Service

```bash
curl -X POST "https://yoursite.com/webservice/rest/server.php" \
  -d "wstoken=YOUR_TOKEN" \
  -d "wsfunction=local_parentmanager_sync_student_parents" \
  -d "moodlewsrestformat=json" \
  -d "studentid=123"
```

## What Happens

For each student:

1. ✅ Calls API with student sequence
2. ✅ For each parent in response:
   - If email exists → **Update** name and phone
   - If email doesn't exist → **Create** new account with auto-generated password
   - **Link** to student via parent role assignment
   - **Email** credentials (new accounts only)

## Email Sent to Parents

New parents receive an email with:
- Username (generated from email)
- Password (auto-generated 12 characters)
- Login URL
- Mobile app link
- What they can access (courses, grades, etc.)

## Troubleshooting

### "No students found"

Students need:
1. The `student` role assigned
2. Custom field `ID` populated with sequence number

Check: **Site Administration > Users > Browse list of users**

### "Parent role not found"

Create role with shortname `parent`:
**Site Administration > Users > Permissions > Define roles**

### "API connection failed"

1. Check Moodle can reach `https://aspire-school.odoo.com`
2. Test the endpoint manually:
   ```bash
   curl "https://aspire-school.odoo.com/api/student/STU001/parents"
   ```
3. Enable debugging: **Site Administration > Development > Debugging**

### View Logs

```bash
tail -f /var/www/html/moodledata/cron.log
```

Or run manually to see output:
```bash
php admin/cli/scheduled_task.php --execute=\\local_parentmanager\\task\\sync_parents
```

## Security

- ✅ Uses Moodle's role system (no custom permissions)
- ✅ Parent role limited to student user context only
- ✅ Auto-generated passwords meet Moodle's policy
- ✅ Email uniqueness enforced
- ✅ HTTPS API calls
- ✅ No sensitive data stored by plugin

## Integration with Financial Dashboard

Parents synced by this plugin automatically get access to:
- 📚 Their children's courses (via `local_aspireparent`)
- 📊 Grades and assignments
- 👥 Teacher messaging
- 💰 Financial dashboard (uses same sequence numbers)

## Support

Check sync status:
```bash
cd /var/www/html/moodle
php local/parentmanager/cli/sync_parents.php --sequence=TEST001
```

## License

GPL v3 or later
