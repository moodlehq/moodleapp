<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

/**
 * Library functions for local_parentmanager
 *
 * @package    local_parentmanager
 * @copyright  2025 Aspire School
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Call Odoo API to get parents for a student
 *
 * @param string $studentsequence Student sequence number
 * @param string &$error Optional reference to store error message
 * @return object|false API response or false on failure
 */
function local_parentmanager_get_student_parents_from_api($studentsequence, &$error = null) {
    $apiurl = get_config('local_parentmanager', 'apiurl') ?: 'https://aspire-school.odoo.com';
    $timeout = get_config('local_parentmanager', 'apitimeout') ?: 30;

    $url = $apiurl . '/api/student/' . urlencode($studentsequence) . '/parents';

    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_TIMEOUT, $timeout);
    curl_setopt($curl, CURLOPT_HTTPHEADER, [
        'Accept: application/json',
        'Content-Type: application/json'
    ]);

    $response = curl_exec($curl);
    $httpcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    $curlerror = curl_error($curl);
    curl_close($curl);

    if ($curlerror) {
        $error = 'cURL error: ' . $curlerror;
        debugging('Failed to fetch parents from API for student ' . $studentsequence . ': ' . $error, DEBUG_DEVELOPER);
        return false;
    }

    if ($httpcode !== 200) {
        $error = 'API returned HTTP ' . $httpcode . ' for sequence ' . $studentsequence;
        debugging($error, DEBUG_DEVELOPER);
        return false;
    }

    if (!$response) {
        $error = 'Empty response from API for sequence ' . $studentsequence;
        debugging($error, DEBUG_DEVELOPER);
        return false;
    }

    $data = json_decode($response);
    if (!$data) {
        $error = 'Invalid JSON response from API for sequence ' . $studentsequence;
        debugging($error, DEBUG_DEVELOPER);
        return false;
    }

    if (!$data->success) {
        $error = isset($data->message) ? 'API error: ' . $data->message : 'API returned success=false for sequence ' . $studentsequence;
        debugging($error, DEBUG_DEVELOPER);
        return false;
    }

    return $data;
}

/**
 * Create or update parent user account
 *
 * @param object $parentdata Parent data from API
 * @return int Parent user ID
 */
function local_parentmanager_create_or_update_parent($parentdata) {
    global $DB, $CFG;
    require_once($CFG->dirroot . '/user/lib.php');
    require_once($CFG->dirroot . '/user/profile/lib.php');

    // Validate required fields
    if (empty($parentdata->email)) {
        throw new \moodle_exception('error', 'local_parentmanager', '', 'Parent email is required');
    }
    if (empty($parentdata->first_name)) {
        throw new \moodle_exception('error', 'local_parentmanager', '', 'Parent first name is required');
    }
    if (empty($parentdata->last_name)) {
        throw new \moodle_exception('error', 'local_parentmanager', '', 'Parent last name is required');
    }

    // Validate email format
    if (!validate_email($parentdata->email)) {
        throw new \moodle_exception('error', 'local_parentmanager', '', 'Invalid email format: ' . $parentdata->email);
    }

    // Clean email
    $parentdata->email = trim(strtolower($parentdata->email));

    // Check if parent exists by email
    $existing = $DB->get_record('user', ['email' => $parentdata->email, 'deleted' => 0]);

    if ($existing) {
        // Update existing user
        $existing->firstname = trim($parentdata->first_name);
        $existing->lastname = trim($parentdata->last_name);
        $existing->phone1 = isset($parentdata->phone) ? clean_param($parentdata->phone, PARAM_TEXT) : '';
        $existing->phone2 = isset($parentdata->mobile) ? clean_param($parentdata->mobile, PARAM_TEXT) : '';
        $existing->timemodified = time();

        try {
            user_update_user($existing, false, false);
        } catch (\Exception $e) {
            throw new \moodle_exception('error', 'local_parentmanager', '', 'Failed to update user: ' . $e->getMessage());
        }

        // Update custom field for sequence
        if (isset($parentdata->sequence) && !empty($parentdata->sequence)) {
            $sequencefield = get_config('local_parentmanager', 'sequencefield') ?: 'ID';
            profile_save_custom_fields($existing->id, [$sequencefield => $parentdata->sequence]);
        }

        return $existing->id;
    }

    // Create new user
    $user = new stdClass();

    // Generate username from email
    $baseusername = strtolower(str_replace(['@', '.', '+', ' ', '-'], ['_', '_', '_', '_', '_'], $parentdata->email));
    $baseusername = preg_replace('/[^a-z0-9_]/', '', $baseusername); // Remove any other special chars
    $baseusername = substr($baseusername, 0, 90); // Limit length

    // Ensure unique username
    $user->username = $baseusername;
    $counter = 1;
    while ($DB->record_exists('user', ['username' => $user->username, 'deleted' => 0])) {
        $user->username = substr($baseusername, 0, 85) . $counter; // Leave room for counter
        $counter++;
        if ($counter > 1000) {
            throw new \moodle_exception('error', 'local_parentmanager', '', 'Could not generate unique username');
        }
    }

    $user->firstname = trim($parentdata->first_name);
    $user->lastname = trim($parentdata->last_name);
    $user->email = $parentdata->email;
    $user->phone1 = isset($parentdata->phone) ? clean_param($parentdata->phone, PARAM_TEXT) : '';
    $user->phone2 = isset($parentdata->mobile) ? clean_param($parentdata->mobile, PARAM_TEXT) : '';
    $user->city = '';
    $user->country = 'AE';
    $user->confirmed = 1;
    $user->mnethostid = $CFG->mnet_localhost_id;
    $user->auth = 'manual';
    $user->lang = $CFG->lang ?: 'en';
    $user->calendartype = 'gregorian';
    $user->timezone = '99';
    $user->mailformat = 1;
    $user->maildigest = 0;
    $user->maildisplay = 2;
    $user->autosubscribe = 1;
    $user->trackforums = 0;

    // Generate password before creating user
    $password = generate_password(12);

    // Create user without password (we'll set it after)
    try {
        $user->id = user_create_user($user, false, false);
    } catch (\Exception $e) {
        throw new \moodle_exception('error', 'local_parentmanager', '', 'Failed to create user: ' . $e->getMessage());
    }

    // Set password
    try {
        update_internal_user_password($user, $password);
    } catch (\Exception $e) {
        throw new \moodle_exception('error', 'local_parentmanager', '', 'Failed to set password: ' . $e->getMessage());
    }

    // Save sequence to custom field
    if (isset($parentdata->sequence) && !empty($parentdata->sequence)) {
        $sequencefield = get_config('local_parentmanager', 'sequencefield') ?: 'ID';
        profile_save_custom_fields($user->id, [$sequencefield => $parentdata->sequence]);
    }

    // Send credentials email (don't fail if email fails)
    try {
        $emailsent = local_parentmanager_send_credentials_email($user, $password);
        if (!$emailsent && get_config('local_parentmanager', 'debugmode')) {
            debugging('Failed to send credentials email to: ' . $user->email, DEBUG_DEVELOPER);
        }
    } catch (\Exception $e) {
        // Log but don't fail the sync
        if (get_config('local_parentmanager', 'debugmode')) {
            debugging('Email error for ' . $user->email . ': ' . $e->getMessage(), DEBUG_DEVELOPER);
        }
    }

    return $user->id;
}

/**
 * Link parent to student via role assignment
 *
 * @param int $parentid Parent user ID
 * @param int $studentid Student user ID
 * @return bool Success status
 */
function local_parentmanager_link_parent_to_student($parentid, $studentid) {
    global $DB;

    // Get parent role (shortname from config)
    $parentrolename = get_config('local_parentmanager', 'parentrole') ?: 'parent';
    $parentrole = $DB->get_record('role', ['shortname' => $parentrolename], '*', IGNORE_MISSING);
    if (!$parentrole) {
        debugging('Parent role not found! Create a role with shortname "parent" at: Site Administration > Users > Permissions > Define roles', DEBUG_DEVELOPER);
        throw new \moodle_exception('parentrolenotfound', 'local_parentmanager');
    }

    // Get student user context
    $studentcontext = context_user::instance($studentid);

    // Check if already assigned
    if (user_has_role_assignment($parentid, $parentrole->id, $studentcontext->id)) {
        return true; // Already linked
    }

    // Assign parent role in the student's user context
    role_assign($parentrole->id, $parentid, $studentcontext->id, '', 0);

    return true;
}

/**
 * Send login credentials to parent via email
 *
 * @param stdClass $parent Parent user object
 * @param string $password Plain text password
 * @return bool Success status
 */
function local_parentmanager_send_credentials_email($parent, $password) {
    global $CFG, $SITE;

    // Check if emails are enabled
    if (!get_config('local_parentmanager', 'sendemails')) {
        return true; // Emails disabled, skip silently
    }

    $from = core_user::get_support_user();
    $subject = get_string('parentcredentialssubject', 'local_parentmanager', $SITE->fullname);

    $messagedata = [
        'sitename' => $SITE->fullname,
        'siteurl' => $CFG->wwwroot,
        'username' => $parent->username,
        'password' => $password,
        'email' => $parent->email,
        'firstname' => $parent->firstname,
        'loginurl' => $CFG->wwwroot . '/login/index.php',
        'mobileappurl' => 'https://apps.apple.com/app/aspire-school/id633359593' // Update with your app URL
    ];

    $message = get_string('parentcredentialsmessage', 'local_parentmanager', $messagedata);
    $messagehtml = get_string('parentcredentialsmessagehtml', 'local_parentmanager', $messagedata);

    return email_to_user($parent, $from, $subject, $message, $messagehtml);
}

/**
 * Sync parents for a specific student
 *
 * @param int $studentid Student user ID
 * @param string $studentsequence Student sequence number
 * @return array Result with counts
 */
function local_parentmanager_sync_student_parents($studentid, $studentsequence) {
    global $DB;

    $result = [
        'success' => false,
        'student_id' => $studentid,
        'student_sequence' => $studentsequence,
        'parents_created' => 0,
        'parents_updated' => 0,
        'parents_linked' => 0,
        'errors' => []
    ];

    // Call API
    $apierror = '';
    $apidata = local_parentmanager_get_student_parents_from_api($studentsequence, $apierror);

    if (!$apidata || !isset($apidata->parents)) {
        $result['errors'][] = $apierror ?: 'No parent data from API for sequence: ' . $studentsequence;
        return $result;
    }

    // Check if parents array is empty
    if (empty($apidata->parents)) {
        $result['success'] = true;
        return $result;
    }

    foreach ($apidata->parents as $parentdata) {
        // Skip if missing required fields
        if (empty($parentdata->email) || empty($parentdata->first_name) || empty($parentdata->last_name)) {
            $result['errors'][] = 'Parent missing required fields (email, first_name, last_name)';
            continue;
        }

        try {
            // Clean email
            $parentdata->email = trim(strtolower($parentdata->email));

            // Check if exists
            $existing = $DB->get_record('user', ['email' => $parentdata->email, 'deleted' => 0]);

            // Create or update
            $parentid = local_parentmanager_create_or_update_parent($parentdata);

            if ($existing) {
                $result['parents_updated']++;
            } else {
                $result['parents_created']++;
            }

            // Link to student
            if (local_parentmanager_link_parent_to_student($parentid, $studentid)) {
                $result['parents_linked']++;
            }

        } catch (\Exception $e) {
            // Get more detailed error message
            $errormsg = $e->getMessage();
            if (method_exists($e, 'debuginfo')) {
                $errormsg .= ' - ' . $e->debuginfo;
            }
            $email = isset($parentdata->email) ? $parentdata->email : 'unknown';
            $result['errors'][] = 'Parent ' . $email . ': ' . $errormsg;

            // Log to Moodle error log if debug mode enabled
            if (get_config('local_parentmanager', 'debugmode')) {
                debugging('Parent sync error for ' . $email . ': ' . $errormsg . ' | Student: ' . $studentid, DEBUG_DEVELOPER);
            }
        }
    }

    $result['success'] = true;
    return $result;
}

/**
 * Reset password for a parent and return the new password
 *
 * @param int $parentid Parent user ID
 * @return array Result with password or error
 */
function local_parentmanager_reset_parent_password($parentid) {
    global $DB, $CFG;
    require_once($CFG->dirroot . '/user/lib.php');

    // Get complete user data including auth field
    $parent = $DB->get_record('user', ['id' => $parentid, 'deleted' => 0], '*', MUST_EXIST);

    if (!$parent) {
        return ['success' => false, 'error' => 'Parent user not found'];
    }

    // Ensure auth is set to manual so password can be changed
    if ($parent->auth !== 'manual') {
        $DB->set_field('user', 'auth', 'manual', ['id' => $parent->id]);
        $parent->auth = 'manual';
    }

    // Generate new password
    $password = generate_password(12);

    try {
        // Update password - this updates both the user object and database
        update_internal_user_password($parent, $password);

        // Verify the password was set correctly
        if (!validate_internal_user_password($parent, $password)) {
            return ['success' => false, 'error' => 'Password verification failed after update'];
        }

        // Try to send email (don't fail if it doesn't work)
        try {
            if (get_config('local_parentmanager', 'sendemails')) {
                local_parentmanager_send_credentials_email($parent, $password);
            }
        } catch (\Exception $e) {
            // Ignore email errors
        }

        return [
            'success' => true,
            'password' => $password,
            'username' => $parent->username,
            'email' => $parent->email,
            'firstname' => $parent->firstname,
            'lastname' => $parent->lastname
        ];
    } catch (\Exception $e) {
        return ['success' => false, 'error' => 'Failed to reset password: ' . $e->getMessage()];
    }
}

/**
 * Get all parent users linked to students
 *
 * @return array Array of parent user objects with student info
 */
function local_parentmanager_get_all_parents() {
    global $DB;

    $parentrolename = get_config('local_parentmanager', 'parentrole') ?: 'parent';
    $parentrole = $DB->get_record('role', ['shortname' => $parentrolename]);

    if (!$parentrole) {
        return [];
    }

    // Get all role assignments for parent role in user contexts
    $sql = "SELECT DISTINCT u.id, u.username, u.firstname, u.lastname, u.email, u.timecreated
            FROM {user} u
            JOIN {role_assignments} ra ON ra.userid = u.id
            JOIN {context} ctx ON ra.contextid = ctx.id
            WHERE ra.roleid = :roleid
            AND ctx.contextlevel = " . CONTEXT_USER . "
            AND u.deleted = 0
            ORDER BY u.lastname, u.firstname";

    return $DB->get_records_sql($sql, ['roleid' => $parentrole->id]);
}
